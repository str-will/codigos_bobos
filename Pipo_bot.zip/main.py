import pipo

if __name__ == "__main__":
    pipo.run_bot()